$(document).ready(
    function(){
$('.calculator').accrue({
    
})


    }
)